adb shell am broadcast -a mono.android.intent.action.SEPPUKU -c mono.android.intent.category.SEPPUKU.mono.samples.texturedcube
