adb shell am start -a android.intent.action.MAIN -n mono.samples.texturedcube/.TexturedCubeActivity
