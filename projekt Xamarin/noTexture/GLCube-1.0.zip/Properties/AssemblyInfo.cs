using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("GLCube")]
[assembly: AssemblyVersion("1.0.0")]
